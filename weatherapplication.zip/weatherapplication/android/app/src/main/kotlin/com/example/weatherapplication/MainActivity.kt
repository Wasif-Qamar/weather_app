package com.example.weatherapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
